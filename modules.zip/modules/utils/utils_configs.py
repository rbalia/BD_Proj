smooth = 1.

img_rows = 128 #480
img_cols = 128 #640
channels = 1

img_rows_proc = 480
img_cols_proc = 640

batch_size = 8

pkgDir = "binaryPkg/"
prdDir = "preds/"
setDir = "dataset/"
tstDir = "test/"
trnDir = "train/"
mskDir = "mask/"
